
public class Main {
    public static void main(String[] args) {
        BaseEntity e = new User("User1");
        e.show();
    }
}
