
public class Payment extends BaseEntity {
    public Payment(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("Payment: " + name);
    }
}
