
public class BankCard extends BaseEntity {
    public BankCard(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("BankCard: " + name);
    }
}
