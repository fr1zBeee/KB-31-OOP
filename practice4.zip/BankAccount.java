
public class BankAccount extends BaseEntity {
    public BankAccount(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("BankAccount: " + name);
    }
}
