
public class BaseEntity {
    protected String name;

    public BaseEntity(String name){
        this.name = name;
    }

    public void show(){
        System.out.println("BaseEntity: " + name);
    }
}
