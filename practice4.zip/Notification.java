
public class Notification extends BaseEntity {
    public Notification(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("Notification: " + name);
    }
}
