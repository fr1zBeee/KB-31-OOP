
public class Transaction extends BaseEntity {
    public Transaction(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("Transaction: " + name);
    }
}
