
public class Loan extends BaseEntity {
    public Loan(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("Loan: " + name);
    }
}
