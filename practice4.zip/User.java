
public class User extends BaseEntity {
    public User(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("User: " + name);
    }
}
