
public class SecuritySystem extends BaseEntity {
    public SecuritySystem(String name){
        super(name);
    }

    @Override
    public void show(){
        System.out.println("SecuritySystem: " + name);
    }
}
