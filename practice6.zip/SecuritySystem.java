
public class SecuritySystem extends AbstractEntity {
    public SecuritySystem(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("SecuritySystem action with " + name);
    }
}
