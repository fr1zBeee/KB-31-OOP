
public class Main {
    public static void main(String[] args) {
        AbstractEntity e = new User("User1");
        e.action();
    }
}
