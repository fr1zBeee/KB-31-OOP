
public class Payment extends AbstractEntity {
    public Payment(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("Payment action with " + name);
    }
}
