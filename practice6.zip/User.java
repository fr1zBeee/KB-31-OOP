
public class User extends AbstractEntity {
    public User(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("User action with " + name);
    }
}
