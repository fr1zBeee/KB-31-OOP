
public class BankCard extends AbstractEntity {
    public BankCard(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("BankCard action with " + name);
    }
}
