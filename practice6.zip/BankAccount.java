
public class BankAccount extends AbstractEntity {
    public BankAccount(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("BankAccount action with " + name);
    }
}
