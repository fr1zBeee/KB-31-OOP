
public class Transaction extends AbstractEntity {
    public Transaction(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("Transaction action with " + name);
    }
}
