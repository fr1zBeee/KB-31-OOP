
public class Loan extends AbstractEntity {
    public Loan(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("Loan action with " + name);
    }
}
