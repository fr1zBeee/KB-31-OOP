
public abstract class AbstractEntity {

    protected String name;

    public AbstractEntity(String name){
        this.name = name;
    }

    public abstract void action();
}
