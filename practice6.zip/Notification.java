
public class Notification extends AbstractEntity {
    public Notification(String name){
        super(name);
    }

    @Override
    public void action(){
        System.out.println("Notification action with " + name);
    }
}
