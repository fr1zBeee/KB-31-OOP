
public class BankCard {
    String name;

    public BankCard() {}

    public BankCard(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("BankCard object: " + name);
    }

    public String toString() {
        return "BankCard{name='" + name + "'}";
    }
}
