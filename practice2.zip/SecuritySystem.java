
public class SecuritySystem {
    String name;

    public SecuritySystem() {}

    public SecuritySystem(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("SecuritySystem object: " + name);
    }

    public String toString() {
        return "SecuritySystem{name='" + name + "'}";
    }
}
