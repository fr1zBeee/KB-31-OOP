
public class Transaction {
    String name;

    public Transaction() {}

    public Transaction(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("Transaction object: " + name);
    }

    public String toString() {
        return "Transaction{name='" + name + "'}";
    }
}
