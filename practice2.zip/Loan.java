
public class Loan {
    String name;

    public Loan() {}

    public Loan(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("Loan object: " + name);
    }

    public String toString() {
        return "Loan{name='" + name + "'}";
    }
}
