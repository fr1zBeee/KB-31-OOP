
public class User {
    String name;

    public User() {}

    public User(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("User object: " + name);
    }

    public String toString() {
        return "User{name='" + name + "'}";
    }
}
