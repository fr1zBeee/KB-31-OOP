
public class Payment {
    String name;

    public Payment() {}

    public Payment(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("Payment object: " + name);
    }

    public String toString() {
        return "Payment{name='" + name + "'}";
    }
}
