
public class BankAccount {
    String name;

    public BankAccount() {}

    public BankAccount(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("BankAccount object: " + name);
    }

    public String toString() {
        return "BankAccount{name='" + name + "'}";
    }
}
