
public class Notification {
    String name;

    public Notification() {}

    public Notification(String name) {
        this.name = name;
    }

    public void printInfo() {
        System.out.println("Notification object: " + name);
    }

    public String toString() {
        return "Notification{name='" + name + "'}";
    }
}
