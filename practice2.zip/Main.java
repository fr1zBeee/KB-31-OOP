
public class Main {
    public static void main(String[] args) {
        User u = new User("User1");
        BankAccount a = new BankAccount("Account1");
        Transaction t = new Transaction("Transaction1");
        BankCard c = new BankCard("Card1");
        SecuritySystem s = new SecuritySystem("Security");
        Payment p = new Payment("Payment1");
        Notification n = new Notification("Notification1");
        Loan l = new Loan("Loan1");

        System.out.println(u);
        System.out.println(a);
        System.out.println(t);
        System.out.println(c);
        System.out.println(s);
        System.out.println(p);
        System.out.println(n);
        System.out.println(l);
    }
}
