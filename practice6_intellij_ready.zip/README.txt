1. Open the project in IntelliJ IDEA.
2. If needed, right-click the src folder and choose "Mark Directory as -> Sources Root".
3. Run Main.java from src/Main.java.
