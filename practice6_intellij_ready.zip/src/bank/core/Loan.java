package bank.core;

public class Loan extends AbstractFinancialEntity {
    public Loan(String id, double amount) {
        super(id, amount);
    }

    public void payPart(double value) {
        amount -= value;
        System.out.println("Loan.payPart(): " + value);
    }

    @Override
    public void showInfo() {
        System.out.println("Loan.showInfo(): " + id);
    }

    @Override
    public void process() {
        System.out.println("Loan.process(): payment control");
    }

    @Override
    public void printState() {
        System.out.println("Loan.printState(): remaining=" + amount);
    }

    @Override
    public String toString() {
        return "Loan{id='" + id + "', amount=" + amount + "}";
    }
}
