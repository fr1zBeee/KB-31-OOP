package bank.core;

public class BankAccount extends AbstractFinancialEntity {
    public BankAccount(String id, double amount) {
        super(id, amount);
    }

    public void deposit(double value) {
        amount += value;
        System.out.println("BankAccount.deposit(): " + value);
    }

    @Override
    public void showInfo() {
        System.out.println("BankAccount.showInfo(): " + id);
    }

    @Override
    public void process() {
        System.out.println("BankAccount.process(): account operation");
    }

    @Override
    public void printState() {
        System.out.println("BankAccount.printState(): balance=" + amount);
    }

    @Override
    public String toString() {
        return "BankAccount{id='" + id + "', amount=" + amount + "}";
    }
}
