package bank.core;

public abstract class AbstractFinancialEntity {
    protected String id;
    protected double amount;

    public AbstractFinancialEntity(String id, double amount) {
        this.id = id;
        this.amount = amount;
    }

    public abstract void showInfo();
    public abstract void process();
    public abstract void printState();
}
