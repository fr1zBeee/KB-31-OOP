package bank.core;

public abstract class AbstractOperationEntity {
    protected String code;
    protected String status;

    public AbstractOperationEntity(String code) {
        this.code = code;
        this.status = "Created";
    }

    public abstract void showInfo();
    public abstract void process();
    public abstract void printState();
}
