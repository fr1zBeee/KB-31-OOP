package bank.core;

public abstract class AbstractClientEntity {
    protected String title;
    protected boolean active;

    public AbstractClientEntity(String title) {
        this.title = title;
        this.active = true;
    }

    public abstract void showInfo();
    public abstract void process();
    public abstract void printState();
}
