package bank.core;

public class Transaction extends AbstractOperationEntity {
    private double amount;

    public Transaction(String code, double amount) {
        super(code);
        this.amount = amount;
    }

    public void completeTransaction() {
        status = "Successful";
        System.out.println("Transaction.completeTransaction(): " + code);
    }

    @Override
    public void showInfo() {
        System.out.println("Transaction.showInfo(): " + code);
    }

    @Override
    public void process() {
        System.out.println("Transaction.process(): transaction execution");
    }

    @Override
    public void printState() {
        System.out.println("Transaction.printState(): amount=" + amount + ", status=" + status);
    }

    @Override
    public String toString() {
        return "Transaction{code='" + code + "', amount=" + amount + ", status='" + status + "'}";
    }
}
