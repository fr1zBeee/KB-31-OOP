package bank.core;

public class Payment extends AbstractFinancialEntity {
    private boolean paid;

    public Payment(String id, double amount) {
        super(id, amount);
        this.paid = false;
    }

    public void confirmPayment() {
        paid = true;
        System.out.println("Payment.confirmPayment(): " + id);
    }

    @Override
    public void showInfo() {
        System.out.println("Payment.showInfo(): " + id);
    }

    @Override
    public void process() {
        System.out.println("Payment.process(): payment process");
    }

    @Override
    public void printState() {
        System.out.println("Payment.printState(): paid=" + paid + ", amount=" + amount);
    }

    @Override
    public String toString() {
        return "Payment{id='" + id + "', amount=" + amount + ", paid=" + paid + "}";
    }
}
