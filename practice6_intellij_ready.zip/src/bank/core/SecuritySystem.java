package bank.core;

public class SecuritySystem extends AbstractClientEntity {
    private boolean locked;

    public SecuritySystem(String title) {
        super(title);
        this.locked = false;
    }

    public void lockSystem() {
        locked = true;
        System.out.println("SecuritySystem.lockSystem()");
    }

    @Override
    public void showInfo() {
        System.out.println("SecuritySystem.showInfo(): " + title);
    }

    @Override
    public void process() {
        System.out.println("SecuritySystem.process(): fraud check");
    }

    @Override
    public void printState() {
        System.out.println("SecuritySystem.printState(): locked=" + locked);
    }

    @Override
    public String toString() {
        return "SecuritySystem{title='" + title + "', locked=" + locked + "}";
    }
}
