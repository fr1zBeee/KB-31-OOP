package bank.core;

public class Notification extends AbstractClientEntity {
    private String message;
    private boolean delivered;

    public Notification(String title, String message) {
        super(title);
        this.message = message;
        this.delivered = false;
    }

    public void send() {
        delivered = true;
        System.out.println("Notification.send(): " + message);
    }

    @Override
    public void showInfo() {
        System.out.println("Notification.showInfo(): " + title);
    }

    @Override
    public void process() {
        System.out.println("Notification.process(): sending message");
    }

    @Override
    public void printState() {
        System.out.println("Notification.printState(): delivered=" + delivered);
    }

    @Override
    public String toString() {
        return "Notification{title='" + title + "', message='" + message + "', delivered=" + delivered + "}";
    }
}
