package bank.core;

public class BankCard extends AbstractOperationEntity {
    private String cardNumber;

    public BankCard(String code, String cardNumber) {
        super(code);
        this.cardNumber = cardNumber;
    }

    public void blockCard() {
        status = "Blocked";
        System.out.println("BankCard.blockCard(): " + cardNumber);
    }

    @Override
    public void showInfo() {
        System.out.println("BankCard.showInfo(): " + cardNumber);
    }

    @Override
    public void process() {
        System.out.println("BankCard.process(): card validation");
    }

    @Override
    public void printState() {
        System.out.println("BankCard.printState(): status=" + status);
    }

    @Override
    public String toString() {
        return "BankCard{code='" + code + "', cardNumber='" + cardNumber + "', status='" + status + "'}";
    }
}
