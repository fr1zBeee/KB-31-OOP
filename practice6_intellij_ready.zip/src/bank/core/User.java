package bank.core;

public class User extends AbstractClientEntity {
    private String email;

    public User(String title, String email) {
        super(title);
        this.email = email;
    }

    public void changeEmail(String newEmail) {
        email = newEmail;
        System.out.println("User.changeEmail(): " + newEmail);
    }

    @Override
    public void showInfo() {
        System.out.println("User.showInfo(): " + title + ", " + email);
    }

    @Override
    public void process() {
        System.out.println("User.process(): authorization");
    }

    @Override
    public void printState() {
        System.out.println("User.printState(): active=" + active);
    }

    @Override
    public String toString() {
        return "User{title='" + title + "', email='" + email + "'}";
    }
}
