package bank.app;

import bank.core.*;

public class BankProcessor {
    public void workWithClient(AbstractClientEntity entity) {
        entity.showInfo();
        entity.process();
        entity.printState();
    }

    public void workWithFinancial(AbstractFinancialEntity entity) {
        entity.showInfo();
        entity.process();
        entity.printState();
    }

    public void workWithOperation(AbstractOperationEntity entity) {
        entity.showInfo();
        entity.process();
        entity.printState();
    }
}
