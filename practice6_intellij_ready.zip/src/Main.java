import bank.app.BankProcessor;
import bank.core.*;

public class Main {
    public static void main(String[] args) {
        BankProcessor processor = new BankProcessor();

        User directUser = new User("Timur", "timur@mail.com");
        directUser.changeEmail("timur.bondarenko@mail.com");
        directUser.showInfo();
        directUser.printState();

        System.out.println("\n---- Same object through abstract reference ----");
        AbstractClientEntity abstractUser = new User("Timur Abstract", "abstract@mail.com");
        processor.workWithClient(abstractUser);

        AbstractClientEntity security = new SecuritySystem("Main Security");
        AbstractClientEntity notification = new Notification("Info", "Payment successful");
        processor.workWithClient(security);
        processor.workWithClient(notification);

        BankAccount directAccount = new BankAccount("ACC001", 5000);
        directAccount.deposit(500);
        directAccount.printState();

        System.out.println("\n---- Financial entities through abstract class ----");
        AbstractFinancialEntity account = new BankAccount("ACC002", 7000);
        AbstractFinancialEntity loan = new Loan("LN001", 12000);
        AbstractFinancialEntity payment = new Payment("PAY001", 800);
        processor.workWithFinancial(account);
        processor.workWithFinancial(loan);
        processor.workWithFinancial(payment);

        Transaction directTransaction = new Transaction("TR001", 1500);
        directTransaction.completeTransaction();
        directTransaction.printState();

        System.out.println("\n---- Operation entities through abstract class ----");
        AbstractOperationEntity transaction = new Transaction("TR002", 2000);
        AbstractOperationEntity card = new BankCard("CARD001", "1111222233334444");
        processor.workWithOperation(transaction);
        processor.workWithOperation(card);

        System.out.println("\n---- toString output ----");
        System.out.println(directUser);
        System.out.println(directAccount);
        System.out.println(directTransaction);
    }
}
