package bank.core;

public class Loan extends FinancialEntity {
    public Loan(String id, double amount) {
        super(id, amount);
    }

    public void payPart(double value) {
        amount -= value;
        System.out.println("Loan.payPart(): " + value);
    }

    @Override
    public String toString() {
        return "Loan{id='" + id + "', amount=" + amount + "}";
    }
}
