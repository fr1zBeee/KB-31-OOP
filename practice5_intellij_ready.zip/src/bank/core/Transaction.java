package bank.core;

public class Transaction extends OperationEntity {
    private double amount;

    public Transaction(String code, double amount) {
        super(code);
        this.amount = amount;
    }

    public void completeTransaction() {
        status = "Successful";
        System.out.println("Transaction.completeTransaction(): " + code);
    }

    @Override
    public String toString() {
        return "Transaction{code='" + code + "', amount=" + amount + ", status='" + status + "'}";
    }
}
