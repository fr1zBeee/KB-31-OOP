package bank.core;

public class BankCard extends OperationEntity {
    private String cardNumber;

    public BankCard(String code, String cardNumber) {
        super(code);
        this.cardNumber = cardNumber;
    }

    public void blockCard() {
        status = "Blocked";
        System.out.println("BankCard.blockCard(): " + cardNumber);
    }

    @Override
    public String toString() {
        return "BankCard{code='" + code + "', cardNumber='" + cardNumber + "', status='" + status + "'}";
    }
}
