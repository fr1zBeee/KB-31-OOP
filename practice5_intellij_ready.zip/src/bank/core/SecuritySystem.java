package bank.core;

public class SecuritySystem extends BaseClientEntity {
    private boolean locked;

    public SecuritySystem(String title) {
        super(title);
        this.locked = false;
    }

    public void lockSystem() {
        locked = true;
        System.out.println("SecuritySystem.lockSystem()");
    }

    @Override
    public String toString() {
        return "SecuritySystem{title='" + title + "', locked=" + locked + "}";
    }
}
