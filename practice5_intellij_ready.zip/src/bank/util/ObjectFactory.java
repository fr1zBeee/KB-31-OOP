package bank.util;

import bank.core.*;
import bank.storage.BankDataStore;

public class ObjectFactory {
    public static User createUser(String shortName, String email, String firstName, String lastName) {
        User user = new User(shortName, email, new User.NameInfo(firstName, lastName));
        BankDataStore.users.add(user);
        return user;
    }

    public static SecuritySystem createSecuritySystem(String title) {
        SecuritySystem securitySystem = new SecuritySystem(title);
        BankDataStore.securitySystems.add(securitySystem);
        return securitySystem;
    }

    public static Notification createNotification(String title, String message) {
        Notification notification = new Notification(title, message);
        BankDataStore.notifications.add(notification);
        return notification;
    }

    public static BankAccount createBankAccount(String id, double amount) {
        BankAccount account = new BankAccount(id, amount);
        BankDataStore.accounts.add(account);
        return account;
    }

    public static Loan createLoan(String id, double amount) {
        Loan loan = new Loan(id, amount);
        BankDataStore.loans.add(loan);
        return loan;
    }

    public static Payment createPayment(String id, double amount) {
        Payment payment = new Payment(id, amount);
        BankDataStore.payments.add(payment);
        return payment;
    }

    public static Transaction createTransaction(String code, double amount) {
        Transaction transaction = new Transaction(code, amount);
        BankDataStore.transactions.add(transaction);
        return transaction;
    }

    public static BankCard createBankCard(String code, String cardNumber) {
        BankCard card = new BankCard(code, cardNumber);
        BankDataStore.cards.add(card);
        return card;
    }
}
