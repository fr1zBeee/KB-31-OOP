
public class BankCard {
    private String name;

    public BankCard(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void show() {
        System.out.println("BankCard: " + name);
    }
}
