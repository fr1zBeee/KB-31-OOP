
public class Loan {
    private String name;

    public Loan(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void show() {
        System.out.println("Loan: " + name);
    }
}
