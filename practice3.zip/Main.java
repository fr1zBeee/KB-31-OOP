
public class Main {
    public static void main(String[] args) {
        User u = new User("User1");
        u.show();
    }
}
