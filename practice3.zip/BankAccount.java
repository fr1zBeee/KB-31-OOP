
public class BankAccount {
    private String name;

    public BankAccount(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void show() {
        System.out.println("BankAccount: " + name);
    }
}
