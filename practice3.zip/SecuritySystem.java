
public class SecuritySystem {
    private String name;

    public SecuritySystem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void show() {
        System.out.println("SecuritySystem: " + name);
    }
}
