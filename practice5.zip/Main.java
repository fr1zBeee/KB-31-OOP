
public class Main {
    public static void main(String[] args) {
        User u = ObjectFactory.createUser("User1");
        Storage.users.add(u);
        Storage.printUsers();
    }
}
