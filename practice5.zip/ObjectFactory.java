
public class ObjectFactory {

    public static User createUser(String name){
        return new User(name);
    }

    public static BankAccount createAccount(String name){
        return new BankAccount(name);
    }
}
