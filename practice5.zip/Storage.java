
import java.util.ArrayList;
import java.util.List;

public class Storage {

    public static List<User> users = new ArrayList<>();

    public static void printUsers(){
        for(User u : users){
            System.out.println(u.getName());
        }
    }
}
