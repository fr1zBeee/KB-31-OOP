
public class BankAccount {
    private String name;

    public BankAccount(String name){
        this.name = name;
    }
}
