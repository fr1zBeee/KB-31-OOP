
import java.util.ArrayList;

public class BankStorage {
    private ArrayList<User> users = new ArrayList<>();

    public void addUser(User user) {
        users.add(user);
    }

    public void showUsers() {
        for (User u : users) {
            System.out.println(u);
        }
    }
}
