
public class User {
    private String name;
    private String email;
    private boolean authorized;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public void authorize() {
        authorized = true;
        System.out.println("User authorized");
    }

    public void changeEmail(String newEmail) {
        email = newEmail;
    }

    void internalCheck() {
        System.out.println("Internal user check");
    }

    public String toString() {
        return name + " " + email;
    }
}
