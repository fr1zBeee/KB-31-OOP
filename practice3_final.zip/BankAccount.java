
public class BankAccount {
    private String number;
    private double balance;

    public BankAccount(String number, double balance) {
        this.number = number;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    void internalAudit() {
        System.out.println("Internal audit");
    }

    public String toString() {
        return number + " " + balance;
    }
}
