
public class Main {
    public static void main(String[] args) {

        User user = new User("Timur", "mail@test.com");
        BankAccount acc = new BankAccount("123", 1000);
        BankStorage storage = new BankStorage();

        user.authorize();
        user.changeEmail("new@mail.com");

        acc.deposit(500);
        acc.withdraw(200);

        storage.addUser(user);
        storage.showUsers();

        user.internalCheck();
        acc.internalAudit();

        System.out.println(user);
        System.out.println(acc);
    }
}
