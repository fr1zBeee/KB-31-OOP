package bank.core;

public class User extends BaseClientEntity {
    protected String email;
    protected boolean blocked;

    public User(String title, String email) {
        super(title);
        this.email = email;
        this.blocked = false;
    }

    public void blockUser() {
        blocked = true;
        active = false;
        System.out.println("User.blockUser(): " + title);
    }

    @Override
    public void showInfo() {
        System.out.println("User.showInfo(): " + title + ", " + email);
    }

    @Override
    public void process() {
        System.out.println("User.process(): authorization for " + title);
    }

    @Override
    public String toString() {
        return "User{title='" + title + "', email='" + email + "', blocked=" + blocked + "}";
    }
}
