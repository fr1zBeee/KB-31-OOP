package bank.core;

public class SecuritySystem extends BaseClientEntity {
    protected boolean locked;

    public SecuritySystem(String title) {
        super(title);
        this.locked = false;
    }

    public void lockSystem() {
        locked = true;
        System.out.println("SecuritySystem.lockSystem(): " + title);
    }

    @Override
    public void showInfo() {
        System.out.println("SecuritySystem.showInfo(): " + title + ", locked=" + locked);
    }

    @Override
    public void process() {
        System.out.println("SecuritySystem.process(): fraud monitoring");
    }

    @Override
    public String toString() {
        return "SecuritySystem{title='" + title + "', locked=" + locked + "}";
    }
}
